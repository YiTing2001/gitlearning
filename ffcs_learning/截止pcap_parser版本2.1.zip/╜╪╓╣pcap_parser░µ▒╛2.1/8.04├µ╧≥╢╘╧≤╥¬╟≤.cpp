#include <iostream>
#include <fstream>
#include <sstream>
#include <cstring>
#include <ctime>
#include <chrono>
#include <iomanip>
#include <pcap.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <signal.h>
#include <sys/resource.h>
#include <unistd.h>

class ConfigurationFile {
private:
    std::string outputPath;
    std::string pcapFilePath;
    std::string logFilePath;

public:
    ConfigurationFile(const std::string& configFile) {
        // �������ļ��ж�ȡ������
        // ...

        // ʾ����Ӳ����������
        outputPath = "/path/to/output";
        pcapFilePath = "/path/to/pcap";
        logFilePath = "/path/to/log";
    }

    std::string getOutputPath() const {
        return outputPath;
    }

    std::string getPcapFilePath() const {
        return pcapFilePath;
    }

    std::string getLogFilePath() const {
        return logFilePath;
    }
};

class LogFile {
private:
    std::ofstream file;
    std::string filePath;
    std::string currentDateString;
    int logFileVersion;
    std::uintmax_t maxLogFileSize;

public:
    LogFile(const std::string& filePath, std::uintmax_t maxLogFileSize)
        : filePath(filePath), currentDateString(""), logFileVersion(1), maxLogFileSize(maxLogFileSize) {
        generateNewLogFile();
    }

    ~LogFile() {
        if (file.is_open()) {
            file.close();
        }
    }

    void generateNewLogFile() {
        std::ostringstream oss;
        oss << "logfile_" << currentDateString << "_" << logFileVersion << ".txt";
        std::string newLogFilePath = filePath + oss.str();

        if (file.is_open()) {
            file.close();
        }

        file.open(newLogFilePath.c_str(), std::ios::app);

        if (file.is_open()) {
            filePath = newLogFilePath;
        }

        logFileVersion++;
    }

    void writeLog(LogLevel level, const std::string& log) {
        std::ostream& outputStream = (level == LogLevel::ERROR) ? std::cerr : file;

        if (outputStream.good()) {
            std::time_t now = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
            std::tm timeInfo;
            localtime_r(&now, &timeInfo);
            char currentDate[11];
            std::strftime(currentDate, sizeof(currentDate), "%Y-%m-%d", &timeInfo);

            if (std::strcmp(currentDate, currentDateString.c_str()) != 0) {
                generateNewLogFile();
                currentDateString = currentDate;
                logFileVersion = 1;
            }

            char currentTime[64];
            std::strftime(currentTime, sizeof(currentTime), "%Y-%m-%d %H:%M:%S", std::localtime(&now));

            outputStream << "[" << currentTime << "] [" << ((level == LogLevel::INFO) ? "Info" : "Error") << "] " << log << std::endl;

            if (isFileSizeGreaterThan(filePath, maxLogFileSize)) {
                std::cout << "�ļ���С����������ƣ����������µ���־�ļ����ڴ��" << std::endl;
                generateNewLogFile();
            }
        }
    }

    std::uintmax_t getFileSize(const std::string& filePath) {
        std::ifstream file(filePath, std::ifstream::binary);
        if (!file.is_open()) {
            std::cerr << "�޷���Ŀ���ļ�����ǰ��" << filePath << "�鿴�ļ��Ƿ�����쳣" << std::endl;
            return 0;
        }

        file.seekg(0, std::ifstream::end);
        std::uintmax_t fileSize = file.tellg();
        file.close();
        return fileSize;
    }

    bool isFileSizeGreaterThan(const std::string& filePath, std::uintmax_t size) {
        std::uintmax_t fileSize = getFileSize(filePath);
        return fileSize > size;
    }
};

class PacketParser {
private:
    LogFile& logFile;
    pcap_t* pcapHandle;
    int count;

public:
    PacketParser(LogFile& logFile, const std::string& pcapFilePath)
        : logFile(logFile), pcapHandle(nullptr), count(0) {
        pcapHandle = pcap_open_offline(pcapFilePath.c_str(), errbuf);

        if (pcapHandle == nullptr) {
            std::cerr << "�޷���pcap�ļ�: ��ǰ��" << pcapFilePath << "�鿴�ļ��Ƿ�����쳣" << errbuf << std::endl;
            logFile.writeLog(LogLevel::ERROR, "�޷���pcap�ļ�");
            return;
        }

        if (pcap_loop(pcapHandle, 0, packetHandler, NULL) < 0) {
            std::cerr << "pcap_loop ����: " << pcap_geterr(pcapHandle) << std::endl;
            logFile.writeLog(LogLevel::ERROR, "����һ��pcap_loop����");
        }

        count++;

        writeLogcount(LogLevel::INFO, count);

        pcap_close(pcapHandle);
        pcapHandle = nullptr;

        std::cout << "������ɡ�" << std::endl;
        sleep(10);
    }

    static void packetHandler(unsigned char* userData, const struct pcap_pkthdr* pkthdr, const unsigned char* packetData) {
        // ���ݰ������߼�
        // ...
    }

    void writeLogcount(LogLevel level, int count) {
        std::ostringstream oss;
        oss << "����������ʼ���ѳɹ�������" << count << "��pcap�ļ�";
        std::string log = oss.str();

        logFile.writeLog(level, log);
    }
};

class MainApplication {
private:
    bool stopSignalReceived;
    ConfigurationFile config;
    LogFile logFile;

public:
    MainApplication(const std::string& configFile, std::uintmax_t maxLogFileSize)
        : stopSignalReceived(false), config(configFile), logFile(config.getLogFilePath(), maxLogFileSize) {
        signal(SIGINT, signal_handler);
        signal(SIGSEGV, signal_handler);
        signal(SIGPIPE, SIG_IGN);
        rlimit core_limits;
        core_limits.rlim_cur = RLIM_INFINITY;
        core_limits.rlim_max = RLIM_INFINITY;
        setrlimit(RLIMIT_CORE, &core_limits);
    }

    void run() {
        while (!stopSignalReceived) {
            logFile.writeLog(LogLevel::INFO, "��������");

            std::string pcapFilePath = config.getPcapFilePath();
            if (!outputFile) {
                std::cerr << "�޷���Ŀ���ļ�����ǰ��" << outputPath << "�鿴�ļ��Ƿ�����쳣" << std::endl;
                logFile.writeLog(LogLevel::ERROR, "�޷���Ŀ���ļ�");
                return;
            }

            PacketParser packetParser(logFile, pcapFilePath);

            std::cout << "������ɡ�" << std::endl;
            sleep(10);
        }

        logFile.writeLog(LogLevel::INFO, "����ֹͣ");
    }
};

int main(int argc, char* argv[]) {
    for (int i = 1; i < argc; ++i) {
        if (std::strcmp(argv[i], "--version") == 0) {
            std::cout << "FJ-pcapparser-Deemo Version 2.0" << std::endl;
            return 0;
        }
    }

    std::string configFile = "config.ini";  // �滻Ϊʵ�ʵ������ļ�·��
    std::uintmax_t maxLogFileSize = 1024;   // �滻Ϊʵ�ʵ������־�ļ���С

    MainApplication app(configFile, maxLogFileSize);
    app.run();

    return 0;
}

