#include <iostream>
#include <fstream>
#include <pcap.h>
#include <netinet/ip.h>
#include <signal.h>
#include <sys/resource.h>
#include <unistd.h>
#include <cstdlib>
#include <sstream>
#include <string>
#include <cstring>
#include <arpa/inet.h>
#include <ctime>
#define _CRT_SECURE_NO_WARNINGS 

enum LogLevel
{
    DEBUG,    
    INFO,     
    WARNING,  
    ERROR     
};


std::ofstream outputFile;
//std::string logFilePath;
pcap_t* pcapHandle;
char errbuf[PCAP_ERRBUF_SIZE];

std::string getConfigValue(const std::string& key) {
    std::ifstream configFile("config.ini");
    std::string line;
    while (std::getline(configFile, line)) {
        size_t delimiterPos = line.find('=');
        if (delimiterPos != std::string::npos) {
            std::string configKey = line.substr(0, delimiterPos);
            if (configKey == key) {
                return line.substr(delimiterPos + 1);
            }
        }
    }
    return "";
}

void packetHandler(unsigned char* userData, const struct pcap_pkthdr* pkthdr, const unsigned char* packetData)
{
    char srcIp[INET_ADDRSTRLEN], dstIp[INET_ADDRSTRLEN];
    outputFile << "Packet Timestamp: " << pkthdr->ts.tv_sec << "." << pkthdr->ts.tv_usec << std::endl;
    const struct ip* ipHeader;
    ipHeader = (struct ip*)(packetData + 14);
    inet_ntop(AF_INET, &(ipHeader->ip_src), srcIp, INET_ADDRSTRLEN);
    inet_ntop(AF_INET, &(ipHeader->ip_dst), dstIp, INET_ADDRSTRLEN);
    outputFile << "Source IP: " << srcIp << std::endl;
    outputFile << "Destination IP: " << dstIp << std::endl;
    outputFile << "��ǰ�ļ�����Ҫ�汾��: " << pcap_major_version(pcapHandle) << std::endl;
    outputFile << "��ǰ�ļ��Ĵ�Ҫ�汾��: " << pcap_minor_version(pcapHandle) << std::endl;
    outputFile << "���Ĵ洢����: " << pcap_snapshot(pcapHandle) << std::endl;
    outputFile << "��·����: Ethernet" << std::endl;
    outputFile << "ץȡ��������֡����: " << pkthdr->len << std::endl;
    outputFile << "�������ݳ���: " << pkthdr->caplen << std::endl;

    outputFile.flush();
}

void signal_handler(int signum) {
    if (signum == SIGINT) {
        std::cout << "�յ�SIGINT�źţ����������˳�..." << std::endl;
        if (pcapHandle != NULL) {
            pcap_breakloop(pcapHandle);
            pcap_close(pcapHandle);
        }
        outputFile.close();
        std::exit(signum);
    }
}

void print_version_info() {
    std::cout << "FJ-pcapparser-Deemo Version 1.4" << std::endl;
}

void writeLog(LogLevel level, const std::string& log)
{  
    std::ofstream file(logFilePath.c_str(), std::ios::app);

    if (file.is_open())
    {
        std::time_t now;
        std::time(&now);
        struct tm timeInfo;
        localtime_r(&now, &timeInfo);  // ʹ��localtime_r�滻localtime_s���ڷ�Windowsƽ̨�ϣ�Ӧ��ʹ��localtime_r����������localtime_s����

        char timestamp[20];
        std::strftime(timestamp, sizeof(timestamp), "%Y-%m-%d %H:%M:%S", &timeInfo);

        std::string levelStr;
        switch (level)
        {
        case DEBUG:
            levelStr = "DEBUG";
            break;
        case INFO:
            levelStr = "INFO";
            break;
        case WARNING:
            levelStr = "WARNING";
            break;
        case ERROR:
            levelStr = "ERROR";
            break;
        }

        file << "[" << timestamp << "] [" << levelStr << "] " << log << std::endl;  // д����־��¼
        file.close();  // �ر��ļ�
    }
}

int main(int argc, char* argv[])
{
    signal(SIGINT, signal_handler);
    signal(SIGSEGV, signal_handler);
    signal(SIGPIPE, SIG_IGN);
    rlimit core_limits;
    core_limits.rlim_cur = RLIM_INFINITY;
    core_limits.rlim_max = RLIM_INFINITY;
    setrlimit(RLIMIT_CORE, &core_limits);

    for (int i = 1; i < argc; ++i) {
        if (std::strcmp(argv[i], "--version") == 0) {
            print_version_info();
            return 0;
        }
    }
  

    while (true) {
        std::string outputPath = getConfigValue("output_path");
        std::string pcapFilePath = getConfigValue("pcap_file_path");
        //std::string logFilePath = getConfigValue("log_file_path");

        outputFile.open(outputPath.c_str(), std::ios::app);
        if (!outputFile) {
            std::cerr << "�޷���Ŀ���ļ���" << std::endl;
            writeLog(ERROR, "�޷���Ŀ���ļ�");
            return 1;
        }

                pcapHandle = pcap_open_offline(pcapFilePath.c_str(), errbuf);
        if (pcapHandle == NULL) {
            std::cerr << "�޷���pcap�ļ�: " << errbuf << std::endl;
            writeLog(ERROR, "�޷���pcap�ļ�");
            return 1;
        }

        if (pcap_loop(pcapHandle, 0, packetHandler, NULL) < 0) {
            std::cerr << "pcap_loop ����: " << pcap_geterr(pcapHandle) << std::endl;
            writeLog(ERROR, "����һ��pcap_loop����");
        }

        pcap_close(pcapHandle);
        pcapHandle = NULL;

        outputFile.close();

        std::cout << "������ɡ�" << std::endl;
        writeLog(INFO, "�ɹ�����һ��");
        sleep(60);
    }

    return 0;
}


