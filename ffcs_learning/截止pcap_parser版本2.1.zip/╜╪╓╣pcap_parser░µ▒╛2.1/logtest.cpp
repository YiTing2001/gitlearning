#include <iostream>
#include <fstream>
#include <ctime>
#include <cstdarg>

enum EnumLogLevel {
    LogLevelAll,       // ������Ϣ��д��־
    LogLevelError,     // д���󡢾�����Ϣ
    LogLevelErrorOnly, // ֻд������Ϣ
    LogLevelNone       // ��д��־
};


const int MAX_STR_LEN = 1024;

class Logger {
public:
    Logger();
    Logger(const char* strLogPath, EnumLogLevel nLogLevel);
    ~Logger();

    void SetLogLevel(EnumLogLevel nLevel);
    void TraceKeyInfo(const char* strInfo, ...);
    void TraceError(const char* strInfo, ...);
    void TraceWarning(const char* strInfo, ...);
    void TraceInfo(const char* strInfo, ...);

private:
    char m_strLogPath[MAX_STR_LEN];
    char m_strCurLogName[MAX_STR_LEN];
    FILE* m_pFileStream;
    EnumLogLevel m_nLogLevel;
    CRITICAL_SECTION m_cs;

    char* GetCurrentTime();
    void Trace(const char* strInfo);
    void GenerateLogName();
    void CreateLogPath();
};

Logger::Logger() {
    // Ĭ�Ϲ��캯����ʵ��
    memset(m_strLogPath, 0, MAX_STR_LEN);
    memset(m_strCurLogName, 0, MAX_STR_LEN);
    m_pFileStream = NULL;
    m_nLogLevel = LogLevelAll;
    InitializeCriticalSection(&m_cs);
    GenerateLogName();
}

Logger::Logger(const char* strLogPath, EnumLogLevel nLogLevel) : m_nLogLevel(nLogLevel) {
    // ���캯����ʵ��
    m_pFileStream = NULL;
    strcpy(m_strLogPath, strLogPath);
    InitializeCriticalSection(&m_cs);
    CreateLogPath();
    GenerateLogName();
}

Logger::~Logger() {
    // ����������ʵ��
    DeleteCriticalSection(&m_cs);
    if (m_pFileStream)
        fclose(m_pFileStream);
}

void Logger::SetLogLevel(EnumLogLevel nLevel) {
    // ����д��־����ĺ���ʵ��
    m_nLogLevel = nLevel;
}

void Logger::TraceKeyInfo(const char* strInfo, ...) {
    // д�ؼ���Ϣ�ĺ���ʵ��
    if (!strInfo)
        return;
    char pTemp[MAX_STR_LEN] = { 0 };
    strcpy(pTemp, GetCurrentTime());
    strcat(pTemp, " [KEY INFO] ");
    va_list arg_ptr = NULL;
    va_start(arg_ptr, strInfo);
    vsprintf(pTemp + strlen(pTemp), strInfo, arg_ptr);
    va_end(arg_ptr);
    Trace(pTemp);
    arg_ptr = NULL;
}

void Logger::TraceError(const char* strInfo, ...) {
    // д������Ϣ�ĺ���ʵ��
    if (m_nLogLevel >= LogLevelErrorOnly)
        return;
    if (!strInfo)
        return;
    char pTemp[MAX_STR_LEN] = { 0 };
    strcpy(pTemp, GetCurrentTime());
    strcat(pTemp, " [ERROR] ");
    va_list arg_ptr = NULL;
    va_start(arg_ptr, strInfo);
    vsprintf(pTemp + strlen(pTemp), strInfo, arg_ptr);
    va_end(arg_ptr);
    Trace(pTemp);
    arg_ptr = NULL;
}

void Logger::TraceWarning(const char* strInfo, ...) {
    // д������Ϣ�ĺ���ʵ��
    if (m_nLogLevel >= LogLevelError)
        return;
    if (!strInfo)
        return;
    char pTemp[MAX_STR_LEN] = { 0 };
    strcpy(pTemp, GetCurrentTime());
    strcat(pTemp, " [WARNING] ");
    va_list arg_ptr = NULL;
    va_start(arg_ptr, strInfo);
    vsprintf(pTemp + strlen(pTemp), strInfo, arg_ptr);
    va_end(arg_ptr);
    Trace(pTemp);
    arg_ptr = NULL;
}

void Logger::TraceInfo(const char* strInfo, ...) {
    // дһ����Ϣ�ĺ���ʵ��
    if (m_nLogLevel >= LogLevelError)
        return;
    if (!strInfo)
        return;
    char pTemp[MAX_STR_LEN] = { 0 };
    strcpy(pTemp, GetCurrentTime());
    strcat(pTemp, " [INFO] ");
    va_list arg_ptr = NULL;
    va_start(arg_ptr, strInfo);
    vsprintf(pTemp + strlen(pTemp), strInfo, arg_ptr);
    va_end(arg_ptr);
    Trace(pTemp);
    arg_ptr = NULL;
}

char* Logger::GetCurrentTime() {
    // ��ȡ��ǰϵͳʱ��ĺ���ʵ��
    time_t curTime;
    struct tm* pTimeInfo = NULL;
    time(&curTime);
    pTimeInfo = localtime(&curTime);
    char temp[MAX_STR_LEN] = { 0 };
    sprintf(temp, "%02d:%02d:%02d", pTimeInfo->tm_hour, pTimeInfo->tm_min, pTimeInfo->tm_sec);
    char* pTemp = temp;
    return pTemp;
}

void Logger::Trace(const char* strInfo) {
    // д�ļ������ĺ���ʵ��
    if (!strInfo)
        return;
    try {
        EnterCriticalSection(&m_cs);
        if (!m_pFileStream) {
            char temp[MAX_STR_LEN] = { 0 };
            strcat(temp, m_strLogPath);
            strcat(temp, m_strCurLogName);
            m_pFileStream = fopen(temp, "a+");
            if (!m_pFileStream) {
                return;
            }
        }
        fprintf(m_pFileStream, "%s\n", strInfo);
        fflush(m_pFileStream);
        LeaveCriticalSection(&m_cs);
    }
    catch (...) {
        LeaveCriticalSection(&m_cs);
    }
}

void Logger::GenerateLogName() {
    // ������־�ļ������Ƶĺ���ʵ��
    time_t curTime;
    struct tm* pTimeInfo = NULL;
    time(&curTime);
    pTimeInfo = localtime(&curTime);
    char temp[MAX_STR_LEN] = { 0 };
    sprintf(temp, "%04d-%02d-%02d.log", pTimeInfo->tm_year + 1900, pTimeInfo->tm_mon + 1, pTimeInfo->tm_mday);
    if (0 != strcmp(m_strCurLogName, temp)) {
        strcpy(m_strCurLogName, temp);
        if (m_pFileStream)
            fclose(m_pFileStream);
        char temp[MAX_STR_LEN] = { 0 };
        strcat(temp, m_strLogPath);
        strcat(temp, m_strCurLogName);
        m_pFileStream = fopen(temp, "a+");
    }
}

void Logger::CreateLogPath() {
    // ������־�ļ���·���ĺ���ʵ��
    if (0 != strlen(m_strLogPath)) {
        strcat(m_strLogPath, "\\");
    }
    MakeSureDirectoryPathExists(m_strLogPath);
}

