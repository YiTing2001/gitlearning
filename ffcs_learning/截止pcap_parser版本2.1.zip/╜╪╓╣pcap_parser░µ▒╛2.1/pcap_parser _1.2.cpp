#include <iostream>
#include <fstream>
#include <pcap.h>
#include <netinet/ip.h>
#include <signal.h>
#include <sys/resource.h>
#include <unistd.h>
#include <cstdlib>
#include <sstream>
#include <string>

using namespace std;

ofstream outputFile;
pcap_t* pcapHandle;
char errbuf[PCAP_ERRBUF_SIZE];

string getConfigValue(const string& key) {
    ifstream configFile("config.ini");
    string line;
    while (getline(configFile, line)) {
        size_t delimiterPos = line.find('=');
        if (delimiterPos != string::npos) {
            string configKey = line.substr(0, delimiterPos);
            if (configKey == key) {
                return line.substr(delimiterPos + 1);
            }
        }
    }
    return "";
}

void packetHandler(unsigned char* userData, const struct pcap_pkthdr* pkthdr, const unsigned char* packetData)
{
    outputFile << "Packet Timestamp: " << pkthdr->ts.tv_sec << "." << pkthdr->ts.tv_usec << endl;
    const struct ip* ipHeader;
    ipHeader = (struct ip*)(packetData + 14);
    outputFile << "Source IP: " << inet_ntoa(ipHeader->ip_src) << endl;
    outputFile << "Destination IP: " << inet_ntoa(ipHeader->ip_dst) << endl;
    outputFile << "��ǰ�ļ�����Ҫ�汾��: " << pcap_major_version(pcapHandle) << endl;
    outputFile << "��ǰ�ļ��Ĵ�Ҫ�汾��: " << pcap_minor_version(pcapHandle) << endl;
    outputFile << "���Ĵ洢����: " << pcap_snapshot(pcapHandle) << endl;
    outputFile << "��·����: Ethernet" << endl;
    outputFile << "ץȡ��������֡����: " << pkthdr->len << endl;
    outputFile << "�������ݳ���: " << pkthdr->caplen << endl;

    outputFile.flush();
}

void signal_handler(int signum) {
    if (signum == SIGINT) {
        cout << "�յ�SIGINT�źţ����������˳�..." << endl;
        if (pcapHandle != NULL) {
            pcap_breakloop(pcapHandle);
            pcap_close(pcapHandle);
        }
        outputFile.close();
        exit(signum);
    }
}

void print_version_info() {
    cout << "FJ-pcapparser-Deemo Version 1.2" << endl;
}

int main()
{
    signal(SIGINT, signal_handler);
    signal(SIGSEGV, signal_handler);
    signal(SIGPIPE, SIG_IGN);
    rlimit core_limits;
    core_limits.rlim_cur = RLIM_INFINITY;
    core_limits.rlim_max = RLIM_INFINITY;
    setrlimit(RLIMIT_CORE, &core_limits);

    print_version_info();

    while (true) {
        string outputPath = getConfigValue("output_path");
        string pcapFilePath = getConfigValue("pcap_file_path");

        outputFile.open(outputPath.c_str(), ios::app);
        if (!outputFile) {
            cerr << "�޷���Ŀ���ļ���" << endl;
            return 1;
        }

        pcapHandle = pcap_open_offline(pcapFilePath.c_str(), errbuf);
        if (pcapHandle == NULL) {
            cerr << "�޷���pcap�ļ���" << errbuf << endl;
            outputFile.close();
            sleep(60);
            continue;
        }

        if (pcap_loop(pcapHandle, 0, packetHandler, NULL) < 0) { 
            cerr << "���ݰ�����ʱ��������" << pcap_geterr(pcapHandle) << endl;
            pcap_close(pcapHandle);
            outputFile.close();
            sleep(60);
            continue;
        }

        pcap_close(pcapHandle);
        outputFile.close();

        cout << "������ɡ�" << endl;
        sleep(60);
    }

    return 0;
}

